config FRAME_VECTOR
	tristate
